import React from 'react';

export default function Footer() {
  return (
    <footer className="site-footer">
      <p>© 2025 Book Finder Project</p>
    </footer>
  );
}
